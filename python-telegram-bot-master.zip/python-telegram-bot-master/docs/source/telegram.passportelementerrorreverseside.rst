telegram.PassportElementErrorReverseSide
========================================

.. autoclass:: telegram.PassportElementErrorReverseSide
    :members:
    :show-inheritance:
