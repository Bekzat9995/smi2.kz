telegram.BotCommand
===================

.. autoclass:: telegram.BotCommand
    :members:
    :show-inheritance: