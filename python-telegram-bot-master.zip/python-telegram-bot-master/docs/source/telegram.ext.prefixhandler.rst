telegram.ext.PrefixHandler
===========================

.. autoclass:: telegram.ext.PrefixHandler
    :members:
    :show-inheritance:
