telegram.utils.promise.Promise
==============================

.. autoclass:: telegram.utils.promise.Promise
    :members:
    :show-inheritance:
