telegram.Callbackgame
=====================

.. autoclass:: telegram.CallbackGame
    :members:
    :show-inheritance:
