telegram.ShippingOption
=======================

.. autoclass:: telegram.ShippingOption
    :members:
    :show-inheritance:
