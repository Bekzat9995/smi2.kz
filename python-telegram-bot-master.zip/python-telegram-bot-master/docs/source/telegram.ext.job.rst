telegram.ext.Job
=====================

.. autoclass:: telegram.ext.Job
    :members:
    :show-inheritance:
