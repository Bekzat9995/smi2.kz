telegram.PhotoSize
==================

.. autoclass:: telegram.PhotoSize
    :members:
    :show-inheritance:
