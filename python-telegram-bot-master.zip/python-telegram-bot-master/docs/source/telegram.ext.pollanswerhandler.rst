telegram.ext.PollAnswerHandler
==============================

.. autoclass:: telegram.ext.PollAnswerHandler
    :members:
    :show-inheritance:
