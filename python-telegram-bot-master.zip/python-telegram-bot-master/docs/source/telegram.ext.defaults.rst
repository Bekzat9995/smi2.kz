telegram.ext.Defaults
=====================

.. autoclass:: telegram.ext.Defaults
    :members:
    :show-inheritance:
