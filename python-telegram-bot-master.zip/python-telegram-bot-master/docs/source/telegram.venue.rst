telegram.Venue
==============

.. autoclass:: telegram.Venue
    :members:
    :show-inheritance:
